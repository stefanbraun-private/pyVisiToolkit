#!/usr/bin/env python
# encoding: utf-8
"""
visu.psc.Parser.py

Copyright (C) 2016 Stefan Braun

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.
"""

import collections
import re
import random

DEBUGGING = False

class PscFile(object):
	def __init__(self, filename):
		self._filename = filename
		self._visu_elems = []
		self._psc_window = None

	def parse_file(self):
		"""
		Separation line-by-line into graphic objects "PSC window" and every "PSC element",
		handing all sourcecode lines to the fresh created objects
		"""
		# reading textfile: example from
		# https://docs.python.org/2/tutorial/inputoutput.html#methods-of-file-objects
		# http://stackoverflow.com/questions/8009882/how-to-read-large-file-line-by-line-in-python
		# http://stackoverflow.com/questions/3277503/python-read-file-line-by-line-into-array
		with open(self._filename, 'r') as f:
			curr_elem = collections.OrderedDict()
			curr_window = collections.OrderedDict()
			for line in f:
				curr_line = line.rstrip('\n\r')
				property_str = curr_line.split(';')[0]
				if property_str in PscWindow.LINE_PREFIXES:
					# found window definition
					curr_window[property_str] = curr_line
				else:
					if property_str == 'ID' and len(curr_elem) != 0:
						# this is begin of new graph element =>process last element, prepare for next element
						self._add_graph_elem(curr_elem)
						curr_elem = collections.OrderedDict()
					curr_elem[property_str] = curr_line

			# process last element and window properties
			self._add_graph_elem(curr_elem)
			self._psc_window = PscWindow(curr_window)


	def _add_graph_elem(self, lines_dict):
		# generate psc object according to it's ID
		# expected line in PSC file:
		# ID;0;Editbox
		curr_ID = lines_dict['ID'].split(';')[2]
		if DEBUGGING:
			print('Parsed PSC element "' + curr_ID + '"')
		new_elem = OBJ_DICT[curr_ID](lines_dict)
		self._visu_elems.append(new_elem)

	def get_psc_elem_list(self):
		curr_list = []
		for elem in self._visu_elems:
			curr_list.append(elem.get_property('id') + ': selection area\t' + str(elem.get_property('selection-area')))
		return curr_list

	def get_elem_list_at_coordinate(self, pos_x, pos_y):
		curr_list = []
		for elem in self._visu_elems:
			if elem.is_obj_at_coordinate(pos_x, pos_y):
				curr_list.append(elem)
		return curr_list

class point(object):
	def __init__(self, x_int, y_int):
		self.x = int(x_int)
		self.y = int(y_int)

	def __repr__(self):
		return '(' + str(self.x) + ',' + str(self.y) + ')'


class rectangle(object):
	def __init__(self, x_left_int, y_up_int, x_right_int, y_down_int):
		assert x_left_int <= x_right_int, 'right coordinate is expected to be equal or greater than left coordinate'
		assert y_up_int <= y_down_int, 'higher coordinate is expected to be equal or less than bottom coordinate'
		self._point1 = point(x_left_int, y_up_int)
		self._point2 = point(x_right_int, y_down_int)

	def is_point_in_area(self, x_int, y_int):
		return (self._point1.x <= x_int <= self._point2.x) and (self._point1.y <= y_int <= self._point2.y)

	def __repr__(self):
		return '[' + str(self._point1) + ',' + str(self._point2) + ']'

class RGB(object):
	# FIXME: how to simplify handling of color RGB values? Which functionality is needed?
	# we use usualy Windows default colormap as shown in MS Paint
	# (how to get color of any pixel in an image: http://www.bustatech.com/simple-way-to-get-rgb-value-of-the-color-on-your-screen/ )
	#
	# Python code for 551 named color constants:
	# https://www.webucator.com/blog/2015/03/python-color-constants-module/
	# useful: https://wiki.python.org/moin/BitManipulation

	def __init__(self, rgb_val):
		red_int, green_int, blue_int = 0, 0, 0
		if isinstance(rgb_val, int):
			self._rgb_int = rgb_val
		else:
			try:
				if rgb_val[0] == '#':
					# assume HTML-colorcode as 3x8bit hexstring '#RRGGBB'
					assert len(rgb_val) == 7
					red_int = int('0x' + rgb_val[1:3], 16)
					green_int = int('0x' + rgb_val[3:5], 16)
					blue_int = int('0x' + rgb_val[5:7], 16)
					self._rgb_int = (red_int << 16) + (green_int << 8) + blue_int
				elif len(rgb_val) == 3 and rgb_val != str(rgb_val):
					# assume color definition as tuple of (red_int, green_int, blue_int) with values between 0 and 255
					red_int, green_int, blue_int = map(int, rgb_val)
					self._rgb_int = (red_int << 16) + (green_int << 8) + blue_int
				else:
					# assume color definition in Visi+: RGB, 8bit per color, hexcode 0xRRGGBB is represented as integer
					self._rgb_int = int(rgb_val)
			except:
				raise ValueError
		assert red_int >= 0 and red_int <= 255
		assert green_int >= 0 and green_int <= 255
		assert blue_int >= 0 and blue_int <= 255
		assert self._rgb_int >= 0 and self._rgb_int <= 0xffffff


	def get_tuple(self):
		mask_red = int('0xff0000',16)
		value_red = (self._rgb_int & mask_red) >> 16

		mask_green = int('0x00ff00',16)
		value_green = (self._rgb_int & mask_green) >> 8

		mask_blue = mask_green = int('0x0000ff',16)
		value_blue = self._rgb_int & mask_blue

		return value_red, value_green, value_blue

	def get_int(self):
		return self._rgb_int

	def get_html(self):
		# return HTML-colorcode as string '#RRGGBB'
		hex_string = hex(self._rgb_int).upper()[2:]

		# string filled to a fixed length with zeros
		# based on http://stackoverflow.com/questions/5676646/fill-out-a-python-string-with-spaces
		return '#' + hex_string.rjust(6, '0')

	def __repr__(self):
		val_r, val_g, val_b = self.get_tuple()
		return 'RGB(' + ','.join([str(val_r), str(val_g), str(val_b)]) + ')'


class PscWindow(object):
	LINE_PREFIXES = ['WPL', 'WIN', 'UMI']
	def __init__(self, lines_dict):
		self.lines_dict = lines_dict


class PscElem(object):
	cnt_int = 0

	def __init__(self):
		# properties were parsed from the raw "self._lines_dict"
		self._properties_dict = {}

		# get draw order
		PscElem.cnt_int = PscElem.cnt_int + 1
		self.set_property('draw-order', PscElem.cnt_int, new_key=True)

		# extract properties from the loaded PSC file
		self._parse_properties()


	def _parse_properties(self):
		"""
		Grab all relevant properties from the raw sourcecode lines
		"""

		# Every PSC object has an ID... expected ID format:
		# ID;0;Editbox
		curr_val = self._lines_dict['ID'].split(';')[2]
		self.set_property('id', curr_val, new_key=True)

		# assumption: every PSC object has a LIBRARY association...
		# expected LIBRARY formats:
		# LIB;;;;
		# LIB;DIN02 Allg.plb;DIN02;BMO:DIN02;BMO:DIN02
		# LIB;DIN02 Allg.plb;DIN02;MSR11:TEST;BMO:DIN02
		parts = self._lines_dict['LIB'].split(';')
		self.set_property('library', parts[1], new_key=True)
		self.set_property('bmo-class', parts[2], new_key=True)
		self.set_property('bmo-instance', parts[3], new_key=True)
		self.set_property('bmo-class-key', parts[4], new_key=True)

		# assumption: every PSC object has a PSDV selection area definition...
		# expected PSDV formats (LINK and LINKBOXEN are Visi.Plus >= v1.6):
		# PSDV;0;0;105;23;12288;1;0;0;0;0;0;1;1
		# PSDV;0;0;208;14;32;1;0;2;0;0;1590;1;LINK;1590;1548;86;0;0;0;1;0;;;;1
		# PSDV;-7;549;0;559;16;1;0;2;0;0;1741;1;LINKBOXEN;1542;1589;94;1;0;0;0;0;;;;1
		parts = self._lines_dict['PSDV'].split(';')
		curr_val = rectangle(int(parts[1]), int(parts[2]), int(parts[3]), int(parts[4]))
		self.set_property('selection-area', curr_val, new_key=True)

		self.set_property('group', int(parts[11]), new_key=True)


		# assumption: every PSC object stores colors in property PEN...
		# expected PEN format:
		# PEN;1;255;0;1;1;0;0;0;0;1;16777215;0;0
		parts = self._lines_dict['PEN'].split(';')
		self.set_property('fgcolor', RGB(parts[2]), new_key=True)
		self.set_property('bgcolor', RGB(parts[11]), new_key=True)


	def get_property(self, prop_str):
		"""
		Retrieve PSC graphic element property ("prop_str" is a dictionary key =>case-sensitive!)
		"""
		return self._properties_dict[prop_str]


	def set_property(self, prop_str, val, new_key=False):
		"""
		Set PSC graphic element property: ("prop_str" is a dictionary key =>case-sensitive!)

		=>when "new_key" is set, then we expect adding a new property (minimal protection against wrong spelling or overwriting)
		"""
		if new_key:
			assert prop_str not in self._properties_dict
		self._properties_dict[prop_str] = val
		# FIXME: How to synchronize changes to raw sourcecode lines? (enable writing of PSC files...)
		# FIXME: Subclasses of PSC-classes could implement writing of difference between counter-part of "_parse_properties()" and raw sourcecode lines


	def get_properties_list(self):
		"""
		Get a list of all available properties of this PSC graphic element
		"""
		return self._properties_dict.keys()


	def is_obj_at_coordinate(self, pos_x, pos_y):
		sel_Area = self.get_property('selection-area')
		return sel_Area.is_point_in_area(int(pos_x), int(pos_y))

	def __repr__(self):
		myStr = ''
		for currProp in self._properties_dict:
			myStr = myStr + '\t' + currProp + '=' + repr(self.get_property(currProp))
		return myStr


class PscLine(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)

	def _parse_properties(self):
		# first run parsing of general properties in superclass
		PscElem._parse_properties(self)

		# Line: endpoints have the same coordinates as selection area
		curr_val = self.get_property('selection-area')
		self.set_property('endpoints', curr_val, new_key=True)


class PscButton(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)

	def _parse_properties(self):
		# first run parsing of general properties in superclass
		PscElem._parse_properties(self)

		# Buttons: endpoints have the same coordinates as selection area
		curr_val = self.get_property('selection-area')
		self.set_property('endpoints', curr_val, new_key=True)


class PscCheckbox(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)


class PscCircle(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)


class PscCombobox(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)


class PscEditbox(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)


class PscIcon(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)


class PscPolyline(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)


class PscRadiobutton(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)


class PscRectangle(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)

	def _parse_properties(self):
		# first run parsing of general properties in superclass
		PscElem._parse_properties(self)

		# Rectangle: endpoints have the same coordinates as selection area
		curr_val = self.get_property('selection-area')
		self.set_property('endpoints', curr_val, new_key=True)


class PscRoundRectangle(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)


class PscRuler(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)

class PscText(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)

	def _parse_properties(self):
		# first run parsing of general properties in superclass
		PscElem._parse_properties(self)

		# text color: in DIV property
		# DIV;4;255;Text;65535
		parts = self._lines_dict['DIV'].split(';')
		self.set_property('text-color', RGB(parts[2]), new_key=True)

		# text string is also in DIV property, but ';' is not escaped...!
		# use regex for text extraction...
		pattern = re.compile(r'DIV;\d+;\d+;(.*);\d+')
		match = pattern.match(self._lines_dict['DIV'])
		self.set_property('text', match.group(1), new_key=True)


	def __repr__(self):
		return PscElem.__repr__(self) + '\ttext: "' + self.get_property('text') + '"\ttextcolor: ' + repr(self.get_property('text-color'))


class PscTrend(PscElem):
	def __init__(self, lines_dict):
		self._lines_dict = lines_dict
		PscElem.__init__(self)



OBJ_DICT = {    'Line':    PscLine,
                'Button':	PscButton,
                'Checkbox':	PscCheckbox,
                'Circle':	PscCircle,
                'Combobox':	PscCombobox,
                'Editbox':	PscEditbox,
                'Icon':	PscIcon,
                'Polyline':	PscPolyline,
                'Radio Button':	PscRadiobutton,
                'Rectangle':	PscRectangle,
                'Round Rectangle':	PscRoundRectangle,
                'Ruler':	PscRuler,
                'Text':	PscText,
                'Trend':	PscTrend
                }


def main(argv=None):
	filename = 'C:\Promos16\proj\Winterthur_MFH_Schaffhauserstrasse\scr\__H01.psc'
	curr_file = PscFile(filename)

	curr_file.parse_file()
	print('PSC elements in "' + filename + '"')
	for elem in curr_file.get_psc_elem_list():
		print('\t' + str(elem))

	print('\n*** coordinate check ***')
	for x in range(10):
		print('\ntest no. ' + str(x))
		coord = (random.randrange(0, 1280),random.randrange(0, 1024))
		print('At coordinate ' + repr(coord) + ' we have:')
		for elem in curr_file.get_elem_list_at_coordinate(coord[0], coord[1]):
			print(repr(elem))

	# some tests:
	print('\nRGB(123).get_html() = ' + RGB(123).get_html() + '\n')
	print('\nRGB((255,0,0)).get_html() = ' + RGB((255,0,0)).get_html() + '\n')
	print('RGB("123").get_html() = ' + RGB("123").get_html() + '\n')
	print('RGB(#FF00FF).get_html() = ' + RGB('#FF00FF').get_html() + '\n')


	return 0        # success


if __name__ == '__main__':
	status = main()
	# sys.exit(status)