# generate a DMS import file
# BrS, 19.5.2017
#
# =>you should call this script with redirected stdout (we generate MANY lines!)
# python generate_pixelmap_dms.py >Animation_import.dms



# generate pixelmap
for y in range(32):
	row_as_str = str(y).zfill(2)
	print('Animation:Row:' + row_as_str + ':Raw;DWU;0;RW')
	for x in range(32):
		elem_as_str = str(x).zfill(2)
		print('Animation:Row:' + row_as_str + ':_Elem' + elem_as_str + ':PRG;STR;BIT(Raw, ' + str(x) + ');RW')
		print('Animation:Row:' + row_as_str + ':_Elem' + elem_as_str + ';BIT;0;RW')