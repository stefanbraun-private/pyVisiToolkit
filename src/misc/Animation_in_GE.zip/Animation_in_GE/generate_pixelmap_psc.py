# generate a GE PSC file
# BrS, 19.5.2017
#
# =>you should call this script with redirected stdout (we generate MANY lines!)
# python generate_pixelmap_psc.py >__Animation.psc


print('WPL;227;44;0;1;0;663;-1;-1;604;166;680;1244')
print('WIN;617;328;1245;811;1;12632256;0;;;0;0')
print('UMI;0;;')

# generate pixelmap
for y in range(32):
	row_as_str = str(y).zfill(2)
	for x in range(32):
		elem_as_str = str(x).zfill(2)
		print('ID;0;Rectangle')
		print('SHP;0;16;16')
		print('LIB;;;;')
		xpos_left = 185 - x * 5
		xpos_right = xpos_left + 5
		y_pos_up = 155 + y * 5
		y_pos_down = y_pos_up + 5
		print('PSDV;' + str(xpos_left) + ';' + str(y_pos_up) + ';' + str(xpos_right) + ';' + str(y_pos_down) + ';2;1;0;2;0;0;0;1;;0;0;0;0;0;0;0;0;;;;1')
		print('PEN;1;0;0;1;1;0;6;1;1;1;65280;0;0')
		print('IBG;Animation:Row:' + row_as_str + ':_Elem' + elem_as_str + ';16711680;65280')
