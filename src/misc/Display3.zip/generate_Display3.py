# generate_Display3.py
#
# HINT: GE allows maximal 15'000 initialisations at the same time. This limits size of our display...
# =>our current JSON DMS Data Exchange is a bottleneck,
#   writing 100x100 (10'000) pixels as single bits into DMS takes too long.
#   =>using array functionality in DMS/GE.
#
# =>using characters as pixels might give better performance...
# (monotype font: "Courier New")
#   =>quadratic appearance when using "*" as pixel,
#     10 pixels height textfield and fontsize 8 dots,
#     or 4 pixels height textfield and fontsize 5 dots)
# 
# BrS, 18.3.2018

# string template: https://docs.python.org/2/library/string.html
from string import Template

DMS_BASEKEY = 'System:Display3'
SCREEN_WIDTH = 100
SCREEN_HEIGHT = 100
PIXELHEIGHT = 4
PSC_FILENAME = "Display3.psc"
DMS_FILENAME = "Display3.dms"


psc_header = '\n'.join(["WPL;227;44;0;1;0;663;-1;-1;193;26;775;1503",
						"WIN;208;159;1506;877;1;12632256;0;;;0;0",
						"UMI;0;;",
						""])
						
textline_templ = Template('\n'.join(["ID;0;Text",
								"SHP;4;16;16",
								"DIV;3;0;$textline;65535;0;0",
								"FNT;0;2;0;-7;0;0;3;49;1;0;0;400;0;Courier New",
								"LIB;;;;",
								"PSDV;$pos_x1;$pos_y1;$pos_x2;$pos_y2;32;1;0;0;0;0;0;1;;0;0;0;0;0;0;0;0;;;;1",
								"PEN;1;0;0;1;1;0;6;1;1;1;12632256;0;0",
								"ITA;$dmskey;%s;0;-1",
								""]))

								
dms_templ = Template('$dmskey;STR;$dmsvalue;RWS')
								
								
# generate PSC
with open(PSC_FILENAME, 'w') as f:
	f.write(psc_header)
	
	textline = "*" * SCREEN_WIDTH
	for y in range(SCREEN_HEIGHT):
		# every row contains a string (every char is a pixel)
		curr_dmskey = DMS_BASEKEY + ':' + str(y).zfill(3)
		curr_textline = textline_templ.substitute(pos_x1=0,
												pos_y1=(y - 1) * PIXELHEIGHT,
												pos_x2=SCREEN_WIDTH * PIXELHEIGHT,
												pos_y2=y * PIXELHEIGHT,
												textline=textline,
												dmskey=curr_dmskey)
		f.write(curr_textline)
			
# generate DMS importfile
with open(DMS_FILENAME, 'w') as f:
	for y in range(SCREEN_HEIGHT):
		# example of one cells_array: "********"
		curr_dmskey = DMS_BASEKEY + ':' + str(y).zfill(3)
		textline_str = "*" * SCREEN_WIDTH
		curr_dmsline = dms_templ.substitute(dmskey=curr_dmskey,
											dmsvalue=textline_str)
		f.write(''.join([curr_dmsline, '\n']))

