# generate_Display2.py
#
# HINT: GE allows maximal 15'000 initialisations at the same time. This limits size of our display...
# =>our current JSON DMS Data Exchange is a bottleneck,
#   writing 100x100 (10'000) pixels as single bits into DMS takes too long.
#   =>using array functionality in DMS/GE.
# 
# BrS, 15.3.2018

# string template: https://docs.python.org/2/library/string.html
from string import Template

DMS_BASEKEY = 'System:Display2'
SCREEN_WIDTH = 100
SCREEN_HEIGHT = 100
PIXELSIZE = 5
PSC_FILENAME = "Display2.psc"
DMS_FILENAME = "Display2.dms"


psc_header = '\n'.join(["WPL;227;44;0;1;0;663;-1;-1;193;26;775;1503",
						"WIN;208;159;1506;877;1;12632256;0;;;0;0",
						"UMI;0;;",
						""])
						
pixel_templ = Template('\n'.join(["ID;0;Rectangle",
								"SHP;0;16;16",
								"LIB;;;;",
								"PSDV;$pos_x1;$pos_y1;$pos_x2;$pos_y2;2;1;0;2;0;0;0;0;;0;0;0;0;0;0;0;0;;;;1",
								"PEN;1;0;0;1;1;0;6;1;1;1;0;0;0",
								"ISB;$dmskey;0",
								""]))

								
dms_templ = Template('$dmskey;STR;$dmsvalue;RWS')
								
								
# generate PSC
with open(PSC_FILENAME, 'w') as f:
	f.write(psc_header)
	
	for y in range(SCREEN_HEIGHT):
		for x in range(1, SCREEN_WIDTH + 1):
			# every row contains a cells_array
			# ATTENTION: first cell index is 1!
			curr_dmskey = DMS_BASEKEY + ':' + str(y).zfill(3) + ':cells_array[' + str(x) + ']BIT'
			curr_pixel = pixel_templ.substitute(pos_x1=(x - 1) * PIXELSIZE,
												pos_y1=(y - 1) * PIXELSIZE,
												pos_x2=x * PIXELSIZE,
												pos_y2=y * PIXELSIZE,
												dmskey=curr_dmskey)
			f.write(curr_pixel)
			
# generate DMS importfile
with open(DMS_FILENAME, 'w') as f:
	for y in range(SCREEN_HEIGHT):
		# example of one cells_array: "{0,0,0,0,........}"
		curr_dmskey = DMS_BASEKEY + ':' + str(y).zfill(3) + ':cells_array'
		bits_str = ','.join(['0'] * SCREEN_WIDTH)
		curr_dmsvalue = ''.join(['{', bits_str, '}'])
		curr_dmsline = dms_templ.substitute(dmskey=curr_dmskey,
											dmsvalue=curr_dmsvalue)
		f.write(''.join([curr_dmsline, '\n']))

