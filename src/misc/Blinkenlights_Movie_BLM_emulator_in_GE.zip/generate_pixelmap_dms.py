# generate a DMS import file
# for Blinkenlights Emulator
# BrS, 21.5.2017
#
# =>you should call this script with redirected stdout (we generate MANY lines!)
# python generate_pixelmap_dms.py >Blinkenlights_Emulator_import.dms


# bitfield for row enable (one bit per row)
print('BlinkenlightsEmulator:Row:EnableBitfield;DWU;4294967295;RW')
# bitfield for column enable (one bit per column)
print('BlinkenlightsEmulator:Column:EnableBitfield;DWU;4294967295;RW')

# generate pixelmap
for row in range(32):
	row_as_str = str(row).zfill(2)
	
	# every row needs an own enable bit
	print('BlinkenlightsEmulator:Row:_Enable' + row_as_str + ';BIT;0;RW')
	print('BlinkenlightsEmulator:Row:_Enable' + row_as_str + ':PRG;STR;BIT(BlinkenlightsEmulator:Row:EnableBitfield, ' + str(row) + ');RW')
	
	print('BlinkenlightsEmulator:Row:' + row_as_str + ':Raw;DWU;0;RW')
	for column in range(32):
		column_as_str = str(column).zfill(2)
		
		if row == 0:
			# every column needs an own enable bit
			print('BlinkenlightsEmulator:Column:_Enable' + column_as_str + ';BIT;0;RW')
			print('BlinkenlightsEmulator:Column:_Enable' + column_as_str + ':PRG;STR;BIT(BlinkenlightsEmulator:Column:EnableBitfield, ' + str(column) + ');RW')
		
		# handling every pixel
		print('BlinkenlightsEmulator:Row:' + row_as_str + ':_Column' + column_as_str + ';BIT;0;RW')
		print('BlinkenlightsEmulator:Row:' + row_as_str + ':_Column' + column_as_str + ':PRG;STR;BIT(Raw, ' + str(column) + ');RW')
		print('BlinkenlightsEmulator:Row:' + row_as_str + ':_Column' + column_as_str + ':Enable;BIT;0;RW')
		print('BlinkenlightsEmulator:Row:' + row_as_str + ':_Column' + column_as_str + ':Enable:PRG;STR;AND(BlinkenlightsEmulator:Row:_Enable' + row_as_str + ', BlinkenlightsEmulator:Column:_Enable' + column_as_str + ');RW')
		
