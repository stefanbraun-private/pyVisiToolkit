# generate_Display.py
#
# HINT: GE allows maximal 15'000 initialisations at the same time. This limits size of our display...
#
# Current proof-of-concept (very bad performance):
# We use one bit in DMS per pixel, every pixel has visibility controlled by one bit.
# =>for a 100x100 pixel black-white display we need 10'0000 DMS keys...
# 
# BrS, 15.3.2018

# string template: https://docs.python.org/2/library/string.html
from string import Template

DMS_BASEKEY = 'System:Display'
SCREEN_WIDTH = 100
SCREEN_HEIGHT = 100
PIXELSIZE = 5
PSC_FILENAME = "Display.psc"
DMS_FILENAME = "Display.dms"


psc_header = '\n'.join(["WPL;227;44;0;1;0;663;-1;-1;193;26;775;1503",
						"WIN;208;159;1506;877;1;12632256;0;;;0;0",
						"UMI;0;;",
						""])
						
pixel_templ = Template('\n'.join(["ID;0;Rectangle",
								"SHP;0;16;16",
								"LIB;;;;",
								"PSDV;$pos_x1;$pos_y1;$pos_x2;$pos_y2;2;1;0;2;0;0;0;0;;0;0;0;0;0;0;0;0;;;;1",
								"PEN;1;0;0;1;1;0;6;1;1;1;0;0;0",
								"ISB;$dmskey;0",
								""]))

								
dms_templ = Template('$dmskey;BIT;0;RWS')
								
								
# generate PSC
with open(PSC_FILENAME, 'w') as f:
	f.write(psc_header)
	
	for x in range(SCREEN_WIDTH):
		for y in range(SCREEN_HEIGHT):
			curr_pixel = pixel_templ.substitute(pos_x1=x * PIXELSIZE,
												pos_y1=y * PIXELSIZE,
												pos_x2=(x + 1) * PIXELSIZE,
												pos_y2=(y + 1) * PIXELSIZE,
												dmskey=DMS_BASEKEY + ':' + str(x).zfill(3) + ':' + str(y).zfill(3))
			f.write(curr_pixel)
			
# generate DMS importfile
with open(DMS_FILENAME, 'w') as f:
	for x in range(SCREEN_WIDTH):
		for y in range(SCREEN_HEIGHT):
			curr_dmsline = dms_templ.substitute(dmskey=DMS_BASEKEY + ':' + str(x).zfill(3) + ':' + str(y).zfill(3))
			f.write(''.join([curr_dmsline, '\n']))
			
